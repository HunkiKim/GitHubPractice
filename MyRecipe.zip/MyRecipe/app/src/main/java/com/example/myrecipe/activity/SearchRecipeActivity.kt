package com.example.myrecipe.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.inflate
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myrecipe.R
import com.example.myrecipe.Recipe
import com.example.myrecipe.adapter.FbRecipeAdapter
import com.example.myrecipe.databinding.ActivityAddRecipeBinding.inflate
import com.example.myrecipe.databinding.ActivitySearchRecipeBinding
import com.example.myrecipe.fragment.SearchByCategoryFragment
import com.example.myrecipe.fragment.SearchByTitleFragment
import com.firebase.ui.database.FirebaseRecyclerOptions

class SearchRecipeActivity : AppCompatActivity() {
    lateinit var binding: ActivitySearchRecipeBinding
    lateinit var layoutManager: LinearLayoutManager
    lateinit var adapter: FbRecipeAdapter

    var findQuery = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchRecipeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {

        binding.apply{
            findbtn.setOnClickListener {
                var fragment1 = SearchByTitleFragment()
                val transaction = supportFragmentManager.beginTransaction()
                transaction.replace(R.id.frameLayout, fragment1)
                transaction.commit()
            }
            cfindbtn.setOnClickListener {
                var fragment2 = SearchByCategoryFragment()
                val transaction = supportFragmentManager.beginTransaction()
                transaction.replace(R.id.frameLayout, fragment2)
                transaction.commit()
            }

        }
    }


    fun find2(){

    }

    fun clearInput(){

    }
    override fun onStart(){
        super.onStart()

    }

    override fun onStop() {
        super.onStop()

    }


}